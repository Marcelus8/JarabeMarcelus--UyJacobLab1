package com.jarabeuy;
import java.util.Scanner;
public class Car {
	
		    private String carSeater;
		    private int speed;
		    private String shift;
		    private boolean seatBeltworn;
		    private boolean on_Switch;
		    
		    
		    
		    Scanner scan = new Scanner(System.in);
		     
		 public Car(int speed, String carSeater1, String shift, boolean seatBeltworn
				   ){
			  
			   this.speed = speed;
			   this.shift = shift;
			   this.carSeater = carSeater1;
			   this.seatBeltworn = seatBeltworn;
			   
			
		   }
		    
		    
		   public int currentSpeed(){
		        
		       
		        System.out.println("What speed is the car moving currently?");
		        speed = scan.nextInt();
		        return speed;
		        }

		public  String gearShift(){
			String shift1;	 
			System.out.println("Enter the gear shift you want to shift into.");
		          System.out.println("Choices: \n Park\n Drive\n Reverse \n Neutral");
		          shift1 = scan.nextLine();
		          return shift1;
		    }
		    
		public void seatBeltsensor(){
			
			boolean seatBeltworn1 = false;
			System.out.println("Are you wearing your seatbelt?");
			  while (seatBeltworn1 == false) {
			
			String worn = scan.nextLine();
			if (worn.equals("yes") || worn.equals("Yes") ){
				
				seatBeltworn1 = true;
				System.out.println("Wonderful!");
			}
			else if (worn.equals("no") || worn.equals("no") ) {
				seatBeltworn1 = false;
			}
		
			
			  
			System.out.println("Checking seatbelt.....");
		    	if(seatBeltworn1 == true)
		    	{
		    		System.out.println("You now have worn your seatbelt");
		    	}
		    	
		    	else
		    	{
		    		System.out.println("You have not worn your seatbelt");
		    		System.out.println("Have you worn your seatbelt yet?");
		    	}
		    	
			  }
		    	
		 }
		  public void buttonForswitchingCarOn() {
			  
			  String on;
			  System.out.print("Type On to Activate:");
		      on = scan.nextLine();
			  
			 if(on.equals("on") || on.equals("On"))
			 {
				 on_Switch = true;
				 
				 
		     }
			 else
				 System.out.println("Invalid input");
			 
			 if(on_Switch) {
				 
				 System.out.println("Your car is now functioning");
			 }
		  }
			 
			public void buttonCarOff() {
				
			
					
				System.out.println("Turning off");
				
		
			}
				
			 
			 	   
		   
		    
		  public boolean getSeatBeltWorn() {
			   
			   return this.seatBeltworn;
			   
		   }
		  
		  public boolean getOnSwitch() {
			   
			   return this.on_Switch;
			   
		   }  
		  
		  public int getSpeed() {
			  
			 return this.speed;
		  }
		
		public String getShift() {
			
			return   this.shift;
		}
		  
		public String getSeater() {
			return this.carSeater;
		}
	}





