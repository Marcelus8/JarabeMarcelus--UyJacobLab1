package com.jarabeuy;

public class Car2 {

	public static void main(String[] args) {
		
		  Car carObj = new Car(0, "5", "", false);
	        
	        
	     
	        
	        carObj.buttonForswitchingCarOn();
	        carObj.seatBeltsensor();
	        carObj.currentSpeed();
	        carObj.gearShift();
	        
	       
	        

	        System.out.println("Car is now on " + carObj.gearShift() + " mode");
	        System.out.println("The car is now running "+ carObj.getSpeed() + " kmh");
	        System.out.println("This car has "+ carObj.getSeater() + " seaters");    
	
	        carObj.buttonCarOff();
	}

}